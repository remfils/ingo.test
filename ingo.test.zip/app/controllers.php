<?php

$app->get('/', 'App\\Controllers\\MainController::indexAction');