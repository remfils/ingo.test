<?php

$app['debug'] = true;