<?php

$app = require __DIR__ . '/../app/app.php';
require __DIR__ . '/../app/controllers.php';
require __DIR__ . '/../app/config.php';

$app->run();