export default class PageTransition {
    constructor(type, shared_timeline, params) {
        this.transition_type = type;
        this.shared_timeline = shared_timeline;
        this.params = params;
    }
}
