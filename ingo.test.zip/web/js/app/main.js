import React from 'react';
import ReactDOM from 'react-dom';
import 'gsap';

import Application from './Application';

var app = document.getElementById('App');

ReactDOM.render(<Application />, app);