export default {
    DEBUG: true
};